import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleSelectApioptionsComponent } from './single-select-apioptions.component';

describe('SingleSelectApioptionsComponent', () => {
  let component: SingleSelectApioptionsComponent;
  let fixture: ComponentFixture<SingleSelectApioptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SingleSelectApioptionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleSelectApioptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
