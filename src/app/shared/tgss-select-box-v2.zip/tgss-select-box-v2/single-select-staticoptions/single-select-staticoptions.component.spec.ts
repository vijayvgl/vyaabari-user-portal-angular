import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleSelectStaticoptionsComponent } from './single-select-staticoptions.component';

describe('SingleSelectStaticoptionsComponent', () => {
  let component: SingleSelectStaticoptionsComponent;
  let fixture: ComponentFixture<SingleSelectStaticoptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SingleSelectStaticoptionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleSelectStaticoptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
