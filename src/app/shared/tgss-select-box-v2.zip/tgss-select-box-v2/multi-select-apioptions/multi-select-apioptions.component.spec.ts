import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiSelectApioptionsComponent } from './multi-select-apioptions.component';

describe('MultiSelectApioptionsComponent', () => {
  let component: MultiSelectApioptionsComponent;
  let fixture: ComponentFixture<MultiSelectApioptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultiSelectApioptionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiSelectApioptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
