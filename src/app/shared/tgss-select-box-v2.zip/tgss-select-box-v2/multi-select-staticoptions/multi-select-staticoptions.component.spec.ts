import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiSelectStaticoptionsComponent } from './multi-select-staticoptions.component';

describe('MultiSelectStaticoptionsComponent', () => {
  let component: MultiSelectStaticoptionsComponent;
  let fixture: ComponentFixture<MultiSelectStaticoptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultiSelectStaticoptionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiSelectStaticoptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
